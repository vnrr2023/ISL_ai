from time import sleep
for i in range(10):
    sleep(2)
    print("_\t",end=" ")
    